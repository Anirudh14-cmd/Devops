import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle
import os

# Create dummy dataset based on standard logic provided:
# High sugar + age > 35 => Diabetes risk
# High BP => Hypertension risk
# High BMI => Obesity risk
# High HR => Cardiac risk
# Otherwise => Healthy

np.random.seed(42)

# Generate 2000 samples
n_samples = 2000
age = np.random.randint(20, 80, n_samples)
weight = np.random.uniform(50, 130, n_samples) # in kg
height_cm = np.random.uniform(150, 195, n_samples)
height_m = height_cm / 100
bmi = weight / (height_m ** 2)

bp_sys = np.random.randint(90, 180, n_samples)
heart_rate = np.random.randint(60, 120, n_samples)
sugar = np.random.randint(70, 250, n_samples)

symptoms = np.random.choice([0, 1], n_samples) # 1 if they report significant symptoms

# Disease logic for labeling
def determine_risk(row):
    if row['sugar'] > 140 and row['age'] > 35:
        return 'Diabetes'
    elif row['bp_sys'] > 140:
        return 'Hypertension'
    elif row['bmi'] > 30:
        return 'Obesity'
    elif row['heart_rate'] > 100:
        return 'Heart Disease'
    else:
        return 'Healthy'

df = pd.DataFrame({
    'age': age,
    'bmi': bmi,
    'bp_sys': bp_sys,
    'heart_rate': heart_rate,
    'sugar': sugar,
    'symptoms': symptoms
})

df['target'] = df.apply(determine_risk, axis=1)

X = df[['age', 'bmi', 'bp_sys', 'heart_rate', 'sugar', 'symptoms']]
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save the model
model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
with open(model_path, 'wb') as f:
    pickle.dump(model, f)

print(f"Model trained and saved to {model_path}")
print(f"Accuracy on dummy test set: {model.score(X_test, y_test):.2f}")
