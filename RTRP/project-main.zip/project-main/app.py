from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
import pickle
import numpy as np
import os
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super-secret-key' # Use strong secret key in production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Load Model
model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
try:
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
except Exception as e:
    model = None
    print(f"Model not found or error loading: {e}")

# Models
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)

class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    weight = db.Column(db.Float, nullable=False)
    height = db.Column(db.Float, nullable=False)
    bmi = db.Column(db.Float, nullable=False)
    bp_sys = db.Column(db.Integer, nullable=False)
    heart_rate = db.Column(db.Integer, nullable=False)
    sugar = db.Column(db.Integer, nullable=False)
    symptoms = db.Column(db.Integer, nullable=False)
    prediction = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))
        
        user_exists = User.query.filter_by(username=username).first()
        if user_exists:
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, email=email, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    reports = Report.query.filter_by(user_id=current_user.id).order_by(Report.created_at.desc()).all()
    return render_template('dashboard.html', reports=reports)

@app.route('/form', methods=['GET', 'POST'])
@login_required
def form():
    if request.method == 'POST':
        age = int(request.form.get('age'))
        weight = float(request.form.get('weight'))
        height = float(request.form.get('height')) # expected in cm
        bp_sys = int(request.form.get('bp_sys'))
        heart_rate = int(request.form.get('heart_rate'))
        sugar = int(request.form.get('sugar'))
        symptoms_checked = request.form.getlist('symptoms')
        symptoms_val = 1 if len(symptoms_checked) > 0 else 0

        # Calc BMI automatically
        height_m = height / 100.0
        bmi = weight / (height_m * height_m)

        # Make prediction
        if model:
            features = np.array([[age, bmi, bp_sys, heart_rate, sugar, symptoms_val]])
            prediction = model.predict(features)[0]
        else:
            prediction = 'Error: Model not loaded'

        # Save report
        new_report = Report(
            user_id=current_user.id,
            age=age,
            weight=weight,
            height=height,
            bmi=bmi,
            bp_sys=bp_sys,
            heart_rate=heart_rate,
            sugar=sugar,
            symptoms=symptoms_val,
            prediction=prediction
        )
        db.session.add(new_report)
        db.session.commit()

        return redirect(url_for('result', report_id=new_report.id))

    return render_template('form.html')

@app.route('/result/<int:report_id>')
@login_required
def result(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id:
        flash("You do not have permission to view this report.", "danger")
        return redirect(url_for('dashboard'))
    return render_template('result.html', report=report)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
