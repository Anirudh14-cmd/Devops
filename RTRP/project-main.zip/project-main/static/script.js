// This file handles client-side scripts like BMI auto-calculation if not done inline
// We already implemented inline JS for BMI in form.html, 
// here we can add minor UI interactions.

document.addEventListener('DOMContentLoaded', () => {
    // Fade out flash messages after 5 seconds
    const flashes = document.querySelectorAll('[class*="border mb-4 text-sm font-medium flex items-center"]');
    if (flashes.length > 0) {
        setTimeout(() => {
            flashes.forEach(flash => {
                flash.style.opacity = '0';
                flash.style.transition = 'opacity 0.5s ease';
                setTimeout(() => flash.remove(), 500);
            });
        }, 5000);
    }
});
